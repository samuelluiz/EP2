#ifndef PASSAGEIRO_H
#define PASSAGEIRO_H

class Carro;
class Parque;

class Passageiro {
public:
	Passageiro(int id, Carro *c);
	virtual ~Passageiro();
	void entraNoCarro();
	void esperaVoltaAcabar();
	void saiDoCarro();
	void passeiaPeloParque();
	bool parqueFechado();
	void run();

private:
	int id;
	Carro *carro;
};


#endif // PASSAGEIRO_H
