#ifndef CARRO_H
#define CARRO_H

class Parque;

class Carro{

public:
	static const int CAPACIDADE;
	static int numPassageiros;
	static bool voltaAcabou;

	Carro();
	virtual ~Carro();
	void esperaEncher();
	void daUmaVolta();
	void esperaEsvaziar();
	int getNVoltas();
	void run();

private:
	int voltas;
};

#endif // CARRO_H
