#include "Carro.h"
#include "Parque.h"
#include <chrono>
#include <random>
#include <thread>

const int Carro::CAPACIDADE = 5;
int Carro::numPassageiros = 0;


Carro::Carro(){
	this->voltas = 0;
}

Carro::~Carro(){

}

void Carro::esperaEncher(){
	while(Carro::numPassageiros < Carro::CAPACIDADE){
            std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	}
}

void Carro::daUmaVolta(){
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	voltaAcabou = true;
}

void Carro::esperaEsvaziar(){
	while (Carro::numPassageiros > 0){
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    }
}

int Carro::getNVoltas(){
	return voltas;
}

void Carro::run(){
	while (Parque::numPessoas > 0){
		esperaEncher();

		daUmaVolta();

		esperaEsvaziar();

		voltas++;
	}
}
