#include "Passageiro.h"
#include "Carro.h"
#include "Parque.h"
#include <atomic>
#include <chrono>
#include <thread>
#include <cstdlib>

#define MAX_NUM_VOLTAS 50

atomic<int> nPassageiros;

Passageiro::Passageiro(int id, Carro *c){
	this->id = id;
	this->carro = c;
}

Passageiro::~Passageiro(){

}

void Passageiro::entraNoCarro(){
	// < await (!b) SC; delay >
	// Protocolo de entrada do Algoritmo Justo
	// Incrementa o numero de passageiros no carro
    atomic_fetch_add(&nPassageiros, 1);
}

void Passageiro::esperaVoltaAcabar(){
	while(!voltaAcabou){
            std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    }
}

void Passageiro::saiDoCarro(){
	// Decrementa o numero de passageiros no carro
    atomic_fetch_add(&nPassageiros, -1);
	// Protocolo de saida do Algoritmo Justo
}

void Passageiro::passeiaPeloParque() {

	int x = (rand()%5)+1;
	std::this_thread::sleep_for(std::chrono::milliseconds(1000*x));

}

bool Passageiro::parqueFechado() {
	if (carro->getNVoltas() < MAX_NUM_VOLTAS)
		return false;

	return true;
}

void Passageiro::run() {
	while (!parqueFechado()) {
		entraNoCarro(); // protocolo de entrada

		esperaVoltaAcabar();

		saiDoCarro(); // protocolo de saida

		passeiaPeloParque(); // secao nao critica
	}

	// decrementa o numero de pessoas no parque
}

